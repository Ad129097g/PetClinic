package com.tecsup.petclinic.services;

import com.tecsup.petclinic.entities.Pet;
import com.tecsup.petclinic.repositories.PetRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Transactional
public class PetServiceIntegrationTest {

    @Autowired
    private PetRepository petRepository;

    @Autowired
    private PetService petService;

    @BeforeEach
    public void setUp() {

        Pet pet1 = new Pet("Leo", 1, 1);
        Pet pet2 = new Pet("Basil", 1, 1);
        petRepository.save(pet1);
        petRepository.save(pet2);
    }

    @Test
    public void testFindPetByTypeId() {
        int TYPE_ID = 1;
        int SIZE_EXPECTED = 10;

        List<Pet> pets = petService.findByTypeId(TYPE_ID);

        assertEquals(SIZE_EXPECTED, pets.size());
    }

    @Test
    public void testFindByOwnerId() {
        int OWNER_ID = 1;
        int SIZE_EXPECTED = 7;

        List<Pet> pets = petService.findByOwnerId(OWNER_ID);

        assertEquals(SIZE_EXPECTED, pets.size());
    }
}
